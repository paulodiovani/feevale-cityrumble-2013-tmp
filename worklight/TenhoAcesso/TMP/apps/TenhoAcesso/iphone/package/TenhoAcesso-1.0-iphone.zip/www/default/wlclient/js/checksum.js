var WL_CHECKSUM = {"checksum":2957078088,"date":1382645220366,"machine":"ADM_INF_002391"};
/* Date: Thu Oct 24 18:07:00 BRST 2013 */